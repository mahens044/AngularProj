
import {
  HttpClient,
  HttpHeaders,
  HttpParams,
  HttpEventType
} from '@angular/common/http';
import { map, catchError, tap } from 'rxjs/operators';
import { Subject, throwError } from 'rxjs';
import {Post } from './post.model';import { Injectable } from '@angular/core';

@Injectable({providedIn  :'root'})
export class PostsService{
    error = new Subject<string>();

    constructor(private http: HttpClient) {}

    createAndStorePosts(postData){
        this.http
        .post(
          'https://myfirst-firebase-60882.firebaseio.com/posts.json',
          postData
        )
        .subscribe(responseData => {
          console.log(responseData);
        }, error =>{
            this.error.next(error.message);
        } );
        this.fetchPosts();
    }

    fetchPosts(){
        return this.http.get<{ [key:string]: Post}> ('https://myfirst-firebase-60882.firebaseio.com/posts.json')
    .pipe(map(responseData => {
      const postsArray: Post[] = [];
      for(const key in responseData){
        if(responseData.hasOwnProperty(key)){
          postsArray.push({ ...responseData[key], id:key});
        }
      }     
         return postsArray;
    }),
    catchError(errorRes =>{
        return throwError(errorRes);
    })
    );
    
    }

    deletePosts(){
        // return this.http.delete('https://myfirst-firebase-60882.firebaseio.com/posts.json');
        return this.http
        .delete('https://myfirst-firebase-60882.firebaseio.com/posts.json', {
          observe: 'events',
          responseType: 'text'
        })
        .pipe(
          tap(event => {
            console.log(event);
            if (event.type === HttpEventType.Sent) {
              // ...
            }
            if (event.type === HttpEventType.Response) {
              console.log(event.body);
            }
          })
        );
    }
}